const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main(){
  await prisma.user.deleteMany();
  const admin = await prisma.user.create({ data: { name: 'Admin', email: 'admin@ia18.com', password: 'adminpass', role: 'ADMIN', verified: true } });
  const employer = await prisma.user.create({ data: { name: 'Cafe Good Vibes', email: 'owner@cafe.com', password: 'ownerpass', role: 'EMPLOYER', verified: true } });
  const student = await prisma.user.create({ data: { name: 'Student One', email: 'student1@uni.edu', password: 'studentpass', role: 'STUDENT', verified: true } });
  await prisma.job.create({ data: { title: 'Cafe Barista', description: 'Part-time barista shifts on weekends', location: 'Hyderabad', jobType: 'PART_TIME', payMin: 5000, payMax: 8000, remote: false, employerId: employer.id } });
  console.log('Seed finished');
}
main().catch(e=>{ console.error(e); process.exit(1)}).finally(async ()=>{ await prisma.$disconnect(); });
