require('dotenv').config();
const express = require('express');
const cors = require('cors');
const prisma = require('./utils/prisma');
const app = express();
const port = process.env.PORT || 4000;
app.use(cors());
app.use(express.json());
app.get('/', (req,res)=> res.send({ ok:true, message: 'Independence at 18 API' }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/jobs', require('./routes/jobs'));
app.use('/api/applications', require('./routes/applications'));
app.listen(port, ()=> {
  console.log('Server listening on', port);
});
