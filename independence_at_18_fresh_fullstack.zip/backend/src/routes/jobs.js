const express = require('express');
const router = express.Router();
const prisma = require('../utils/prisma');
const { protect, authorize } = require('../middleware/auth');
router.post('/', protect, authorize('EMPLOYER'), async (req,res)=>{
  const data = req.body;
  const job = await prisma.job.create({ data: { ...data, employerId: req.user.id }});
  res.json(job);
});
router.get('/', async (req,res)=>{
  const jobs = await prisma.job.findMany({ include: { employer: true }, orderBy: { createdAt: 'desc' }});
  res.json(jobs);
});
module.exports = router;
