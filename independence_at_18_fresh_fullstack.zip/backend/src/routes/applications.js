const express = require('express');
const router = express.Router();
const prisma = require('../utils/prisma');
const { protect, authorize } = require('../middleware/auth');
router.post('/', protect, authorize('STUDENT'), async (req,res)=>{
  const { jobId, message } = req.body;
  const exists = await prisma.application.findFirst({ where: { jobId, studentId: req.user.id }});
  if(exists) return res.status(400).json({ error:'Already applied' });
  const app = await prisma.application.create({ data: { jobId, studentId: req.user.id, message }});
  res.json(app);
});
router.get('/me', protect, authorize('STUDENT'), async (req,res)=>{
  const apps = await prisma.application.findMany({ where: { studentId: req.user.id }, include: { job: true }});
  res.json(apps);
});
module.exports = router;
