const jwt = require('jsonwebtoken');
const prisma = require('../utils/prisma');
async function protect(req,res,next){
  const h = req.headers.authorization;
  if(!h) return res.status(401).json({error:'No token'});
  const token = h.split(' ')[1];
  try{
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await prisma.user.findUnique({ where: { id: decoded.id }});
    if(!user) return res.status(401).json({error:'User not found'});
    req.user = user;
    next();
  }catch(e){ return res.status(401).json({error:'Invalid token'})}
}
function authorize(...roles){
  return (req,res,next)=>{
    if(!req.user) return res.status(401).json({error:'Not authenticated'});
    if(!roles.includes(req.user.role)) return res.status(403).json({error:'Forbidden'});
    next();
  }
}
module.exports = { protect, authorize };
