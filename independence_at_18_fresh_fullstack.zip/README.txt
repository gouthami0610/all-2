Fresh Independence at 18 - Fullstack (SQLite backend) 
---------------------------------------------------
How to run:

1) Backend:
   cd backend
   npm install
   # copy .env.example to .env (or create .env) -- DATABASE_URL defaults to SQLite file dev.db
   # Example .env content:
   # DATABASE_URL="file:./dev.db"
   # JWT_SECRET="your_secret"
   # PORT=4000
   npx prisma generate
   npx prisma migrate dev --name init
   npm run seed
   npm run dev
   API: http://localhost:4000

2) Frontend:
   cd frontend
   npm install
   npm run dev
   Open: http://localhost:5173
