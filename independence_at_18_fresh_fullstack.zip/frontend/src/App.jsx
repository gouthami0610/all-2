import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import StudentDashboard from './pages/Student/Dashboard'
export default function App(){
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <nav className="p-4 bg-white dark:bg-gray-800 shadow">
        <div className="container mx-auto flex justify-between">
          <Link to="/" className="font-bold">Independence at 18</Link>
          <div className="space-x-4">
            <Link to="/login">Login</Link>
          </div>
        </div>
      </nav>
      <main className="container mx-auto p-4">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/student/dashboard" element={<StudentDashboard/>} />
        </Routes>
      </main>
    </div>
  )
}
