import React from 'react'
export default function StudentDashboard(){
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Student Dashboard</h2>
      <div className="grid md:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow">Jobs Available</div>
        <div className="p-4 bg-white rounded shadow">Applications</div>
        <div className="p-4 bg-white rounded shadow">Earnings</div>
      </div>
    </div>
  )
}
