import React from 'react'
import { Link } from 'react-router-dom'
export default function Home(){
  return (
    <div className="text-center py-10">
      <h1 className="text-4xl font-bold mb-4">Independence at 18</h1>
      <p className="mb-6">India’s First Student-First Part-Time Job Ecosystem</p>
      <div className="space-x-3">
        <Link to="/student/dashboard" className="px-4 py-2 bg-blue-600 text-white rounded">Dashboard</Link>
        <Link to="/login" className="px-4 py-2 border rounded">Login</Link>
      </div>
    </div>
  )
}
