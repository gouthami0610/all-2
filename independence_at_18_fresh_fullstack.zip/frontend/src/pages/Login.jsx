import React from 'react'
export default function Login(){
  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded shadow">
      <h2 className="text-xl font-bold mb-4">Login</h2>
      <p className="mb-4">Use the backend API to signup or login.</p>
    </div>
  )
}
